/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 
package com.sistemagestionventas;

/**
 *
 * @author SEBA
 
*/

//SEBA_MARTINES



package com.sistemagestionventas;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class Main {
    private static BaseDatos baseDatos = new BaseDatos();

    public static void main(String[] args) {
        showWelcomeMessage();
        boolean exit = false;
        while (!exit) {
            int choice = showMainMenu();
            switch (choice) {
                case 1:
                    adminLogin();
                    break;
                case 2:
                    userLogin();
                    break;
                case 3:
                    System.out.println("Gracias por usar el sistema de Patagonia S.A. ¡Hasta luego!");
                    exit = true;
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    private static void showWelcomeMessage() {
        ImageIcon icon = new ImageIcon("C:\\Users\\cualq\\Downloads\\Descargas");
        JOptionPane.showMessageDialog(null, "Bienvenidos a Patagonia S.A.", "Patagonia S.A. ventas", JOptionPane.INFORMATION_MESSAGE, icon);
    }

    private static int showMainMenu() {
        String[] options = {"Administrador", "Usuario", "Salir"};
        int choice = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Menú Principal",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        return choice + 1;
    }

    private static void adminLogin() {
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel(new ImageIcon("path_to_logo/admin.png")));
        panel.add(new JLabel());
        panel.add(new JLabel("Usuario:"));
        panel.add(userField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(passField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Inicio de sesión - Administrador", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if (baseDatos.autenticarUsuario(username, password, true)) {
                adminMenu();
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void userLogin() {
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel(new ImageIcon("path_to_logo/user.png")));
        panel.add(new JLabel());
        panel.add(new JLabel("Usuario:"));
        panel.add(userField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(passField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Inicio de sesión - Usuario", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if (baseDatos.autenticarUsuario(username, password, false)) {
                userMenu();
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void adminMenu() {
        boolean exit = false;
        while (!exit) {
            String[] options = {"Agregar Cliente", "Agregar Usuario", "Ver Stock", "Buscar Producto", "Ver Pedidos", "Agregar Pedido", "Cerrar Sesión"};
            int choice = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Menú Administrador",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            switch (choice) {
                case 0:
                    viewAgregarCliente();
                    break;
                case 1:
                    viewAgregarUsuario();
                    break;
                case 2:
                    viewStock();
                    break;
                case 3:
                    searchProduct();
                    break;
                case 4:
                    viewOrder();
                    break;
                case 5:
                    viewAgregarPedido();
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    private static void userMenu() {
        boolean exit = false;
        while (!exit) {
            String[] options = {"Ver Stock", "Buscar Producto", "Ver Pedidos", "Agregar Pedido", "Cerrar Sesión"};
            int choice = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Menú Usuario",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            switch (choice) {
                case 0:
                    viewStock();
                    break;
                case 1:
                    searchProduct();
                    break;
                case 2:
                    viewOrder();
                    break;
                case 3:
                    viewAgregarPedido();
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    private static void viewAgregarCliente() {
        JTextField apellidoField = new JTextField(15);
        JTextField nombreField = new JTextField(15);
        JTextField direccionField = new JTextField(15);
        JTextField gmailField = new JTextField(15);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Apellido:"));
        panel.add(apellidoField);
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Dirección:"));
        panel.add(direccionField);
        panel.add(new JLabel("Gmail:"));
        panel.add(gmailField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Agregar Cliente", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String apellido = apellidoField.getText();
            String nombre = nombreField.getText();
            String direccion = direccionField.getText();
            String gmail = gmailField.getText();

            baseDatos.agregarCliente(apellido, nombre, direccion, gmail);
            JOptionPane.showMessageDialog(null, "Cliente agregado con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private static void viewAgregarUsuario() {
        JTextField usernameField = new JTextField(15);
        JTextField passwordField = new JTextField(15);
        JCheckBox isAdminCheckBox = new JCheckBox("¿Es administrador?");

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel());
        panel.add(isAdminCheckBox);

        int option = JOptionPane.showConfirmDialog(null, panel, "Agregar Usuario", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = passwordField.getText();
            boolean isAdmin = isAdminCheckBox.isSelected();

            baseDatos.agregarUsuario(username, password, isAdmin);
            JOptionPane.showMessageDialog(null, "Usuario agregado con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private static void viewStock() {
        try {
            List<String> stock = baseDatos.consultarStock();
            if (stock.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay productos en stock actualmente.", "Stock Vacío", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Stock actual de productos:\n");
                for (String producto : stock) {
                    sb.append(producto).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString(), "Stock Actual", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar el stock: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void searchProduct() {
        String descripcion = JOptionPane.showInputDialog("Ingrese la descripción del producto a buscar:");
        if (descripcion != null && !descripcion.trim().isEmpty()) {
            try {
                List<String> productos = baseDatos.buscarProducto(descripcion);
                if (productos.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No se encontraron productos con la descripción proporcionada.", "Búsqueda Vacía", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Productos encontrados:\n");
                    for (String producto : productos) {
                        sb.append(producto).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, sb.toString(), "Resultados de la Búsqueda", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al buscar el producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewOrder() {
        try {
            List<String> pedidos = baseDatos.verPedidos();
            if (pedidos.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay pedidos actualmente.", "Pedidos Vacíos", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Pedidos actuales:\n");
                for (String pedido : pedidos) {
                    sb.append(pedido).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString(), "Pedidos", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar los pedidos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    


    private static void viewAgregarPedido() {
        JTextField clienteField = new JTextField(15);
        JTextField fechaField = new JTextField(15);  // Expected format: yyyy-mm-dd
        JTextField totalField = new JTextField(15);

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Cliente:"));
        panel.add(clienteField);
        panel.add(new JLabel("Fecha (yyyy-mm-dd):"));
        panel.add(fechaField);
        panel.add(new JLabel("Total:"));
        panel.add(totalField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Agregar Pedido", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            String cliente = clienteField.getText();
            String fechaStr = fechaField.getText();
            String totalStr = totalField.getText();

            try {
                Date fecha = Date.valueOf(fechaStr);
                BigDecimal total = new BigDecimal(totalStr);

                baseDatos.agregarPedido(cliente, fecha, total);
                JOptionPane.showMessageDialog(null, "Pedido agregado con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, "Error en el formato de los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}















