/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 
package com.sistemagestionventas;
/**
 *
 * @author SEBAMARTINES
public class BaseDatos {   
}

package com.sistemagestionventas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class BaseDatos {

    private static final String URL = "jdbc:mysql://localhost:3306/SistemaVentas"; // es donde tengo guardado mi proyecto
    private static final String USER = "root"; //use el mismo nombre que vino al inicio
    private static final String PASSWORD = "Martinez44+"; // Esta es mi contraseña actual de host 3306 de MyQSL

    public Connection conectar() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conexion;
    }

    public void agregarCliente(String apellido, String nombre, String direccion, String gmail) {
        String sql = "INSERT INTO Cliente (Apellido, Nombre, Direccion, Gmail) VALUES (?, ?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, apellido);
            pstmt.setString(2, nombre);
            pstmt.setString(3, direccion);
            pstmt.setString(4, gmail);
            pstmt.executeUpdate();
            System.out.println("Cliente agregado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agregarUsuario(String username, String password, boolean isAdmin) {
        String sql = "INSERT INTO Usuario (Username, Password, IsAdmin) VALUES (?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setBoolean(3, isAdmin);
            pstmt.executeUpdate();
            System.out.println("Usuario agregado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean autenticarUsuario(String username, String password, boolean isAdmin) {
        String sql = "SELECT * FROM Usuario WHERE Username = ? AND Password = ? AND IsAdmin = ?";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setBoolean(3, isAdmin);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Aquí puedes agregar más métodos para manejar otras tablas y operaciones
    
     public List<String> consultarStock() throws SQLException {
        List<String> stock = new ArrayList<>();
        String sql = "SELECT Nombre, Cantidad FROM Producto WHERE Cantidad > 0"; // Consulta para obtener productos con cantidad > 0

        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("Nombre");
                int cantidad = rs.getInt("Cantidad");
                stock.add(nombre + " - Cantidad: " + cantidad);
            }
        }
        return stock;
    }
     
    
    /*
    public List<Producto> obtenerStock() {
        List<Producto> productos = new ArrayList<>();
        String query = "SELECT * FROM productos";

        try (Connection con = conectar();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Producto producto = new Producto();
                producto.setIdProducto(rs.getInt("id_producto"));
                producto.setDescripcion(rs.getString("descripcion"));
                producto.setPrecio(rs.getDouble("precio"));
                producto.setStock(rs.getInt("stock"));
                productos.add(producto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productos;
    }

    public Producto buscarProducto(String descripcion) {
        Producto producto = null;
        String query = "SELECT * FROM productos WHERE descripcion LIKE ?";

        try (Connection con = conectar();
             PreparedStatement pstmt = con.prepareStatement(query)) {

            pstmt.setString(1, "%" + descripcion + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    producto = new Producto();
                    producto.setIdProducto(rs.getInt("id_producto"));
                    producto.setDescripcion(rs.getString("descripcion"));
                    producto.setPrecio(rs.getDouble("precio"));
                    producto.setStock(rs.getInt("stock"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return producto;
    }

    public List<VentaPedido> obtenerPedidos() {
        List<VentaPedido> pedidos = new ArrayList<>();
        String query = "SELECT * FROM venta_pedidos";

        try (Connection con = conectar();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                VentaPedido pedido = new VentaPedido();
                pedido.setNroPedido(rs.getInt("nro_pedido"));
                pedido.setIdCliente(rs.getInt("id_cliente"));
                pedido.setFecha(rs.getDate("fecha"));
                pedido.setEstado(rs.getString("estado"));
                pedidos.add(pedido);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pedidos;
    // se agrega }*./

    List<String> consultarPedidos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

*/
//SEBA_MARTINES


package com.sistemagestionventas;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BaseDatos {

    private static final String URL = "jdbc:mysql://localhost:3306/SistemaVentas";
    private static final String USER = "root";
    private static final String PASSWORD = "Martinez44+";

    public Connection conectar() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conexion;
    }

    public void agregarCliente(String apellido, String nombre, String direccion, String gmail) {
        String sql = "INSERT INTO Cliente (Apellido, Nombre, Direccion, Gmail) VALUES (?, ?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, apellido);
            pstmt.setString(2, nombre);
            pstmt.setString(3, direccion);
            pstmt.setString(4, gmail);
            pstmt.executeUpdate();
            System.out.println("Cliente agregado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agregarUsuario(String username, String password, boolean isAdmin) {
        String sql = "INSERT INTO Usuario (Username, Password, IsAdmin) VALUES (?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setBoolean(3, isAdmin);
            pstmt.executeUpdate();
            System.out.println("Usuario agregado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean autenticarUsuario(String username, String password, boolean isAdmin) {
        String sql = "SELECT * FROM Usuario WHERE Username = ? AND Password = ? AND IsAdmin = ?";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setBoolean(3, isAdmin);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<String> consultarStock() throws SQLException {
        List<String> stock = new ArrayList<>();
        String sql = "SELECT * FROM Producto";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                String producto = "ID: " + rs.getInt("IdProducto") + ", Descripción: " + rs.getString("Descripcion") + ", Precio: " + rs.getBigDecimal("Precio") + ", Stock: " + rs.getInt("Stock");
                stock.add(producto);
            }
        }
        return stock;
    }

    public List<String> buscarProducto(String descripcion) throws SQLException {
        List<String> productos = new ArrayList<>();
        String sql = "SELECT * FROM Producto WHERE Descripcion LIKE ?";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + descripcion + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String producto = "ID: " + rs.getInt("IdProducto") + ", Descripción: " + rs.getString("Descripcion") + ", Precio: " + rs.getBigDecimal("Precio") + ", Stock: " + rs.getInt("Stock");
                    productos.add(producto);
                }
            }
        }
        return productos;
    }

    public List<String> verPedidos() throws SQLException {
        List<String> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM Pedido";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                String pedido = "ID Pedido: " + rs.getInt("IdPedido") + ", Cliente: " + rs.getString("Cliente") + ", Fecha: " + rs.getDate("Fecha") + ", Total: " + rs.getBigDecimal("Total");
                pedidos.add(pedido);
            }
        }
        return pedidos;
    }

    public void agregarPedido(String cliente, Date fecha, BigDecimal total) {
        String sql = "INSERT INTO Pedido (Cliente, Fecha, Total) VALUES (?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cliente);
            pstmt.setDate(2, fecha);
            pstmt.setBigDecimal(3, total);
            pstmt.executeUpdate();
            System.out.println("Pedido agregado con éxito");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
